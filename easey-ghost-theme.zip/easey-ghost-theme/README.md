# easey-ghost-theme
Source code for a Ghost theme I've added for personal purposes. Slowly, it is drifting away from the original Ease.
For a live demo of the current site, visit [https://romandesign.co](https://romandesign.co)

## Currently on: 
Version `2.0.17` 

# Notes on Using the Theme:

## Adding Homepage Content:
Create a `page` and tag it with `about`. This page will get published as the homepage content. 
